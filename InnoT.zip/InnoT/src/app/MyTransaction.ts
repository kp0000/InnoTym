export interface MyTransaction{
    transactionId: number;
    refId: number;
    refUserName: string;
    date: Date;
    transactionAmount: number;
    transactionType: String;

}