export interface IUser{
    userId: number;
    name: String;
    email: String;
    password:String;
    amount: number;
}
